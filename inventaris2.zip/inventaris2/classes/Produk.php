<?php


require_once "koneksi.php";

class Produk {

    private $koneksi;

    
    public function __construct() {
        global $koneksi;
        $this->koneksi = $koneksi;
    }

    
    public function tambah($nama, $tipe, $merek, $harga, $stok) {
        
        if ($stok < 0) {
            return "ERROR: Stok tidak boleh negatif!";
        }

        $nama  = mysqli_real_escape_string($this->koneksi, $nama);
        $merek = mysqli_real_escape_string($this->koneksi, $merek);

        $query = "INSERT INTO produk (nama_produk, tipe, merek, harga, stok) 
                  VALUES ('$nama', '$tipe', '$merek', '$harga', '$stok')";

        $hasil = mysqli_query($this->koneksi, $query);

        if ($hasil) {
            return "Produk berhasil ditambahkan!";
        } else {
            return "Gagal menambahkan produk.";
        }
    }

    
    public function getSemuaProduk() {
        $query = "SELECT * FROM produk ORDER BY tipe, nama_produk";
        $hasil = mysqli_query($this->koneksi, $query);
        return $hasil;
    }

    
    public function getProdukById($id) {
        $query = "SELECT * FROM produk WHERE id = $id";
        $hasil = mysqli_query($this->koneksi, $query);
        return mysqli_fetch_assoc($hasil);
    }

    
    public function edit($id, $nama, $tipe, $merek, $harga, $stok) {
        
        if ($stok < 0) {
            return "ERROR: Stok tidak boleh negatif!";
        }

        $nama  = mysqli_real_escape_string($this->koneksi, $nama);
        $merek = mysqli_real_escape_string($this->koneksi, $merek);

        $query = "UPDATE produk SET 
                    nama_produk = '$nama', 
                    tipe = '$tipe',
                    merek = '$merek',
                    harga = '$harga',
                    stok = '$stok'
                  WHERE id = $id";

        $hasil = mysqli_query($this->koneksi, $query);

        if ($hasil) {
            return "Produk berhasil diupdate!";
        } else {
            return "Gagal mengupdate produk.";
        }
    }

    
    public function hapus($id) {
        $query = "DELETE FROM produk WHERE id = $id";
        $hasil = mysqli_query($this->koneksi, $query);

        if ($hasil) {
            return "Produk berhasil dihapus!";
        } else {
            return "Gagal menghapus produk.";
        }
    }

    
    public function cekStokMenipis($stok) {
        if ($stok < 5) {
            return true;
        }
        return false;
    }

    
    public function getProdukMenipis() {
        $query = "SELECT * FROM produk WHERE stok < 5 ORDER BY stok ASC";
        $hasil = mysqli_query($this->koneksi, $query);
        return $hasil;
    }
}
?>
