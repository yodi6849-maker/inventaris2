<?php
// classes/Transaksi.php
// Class untuk mengelola transaksi pengurangan stok

require_once "koneksi.php";

class Transaksi {

    private $koneksi;

    public function __construct() {
        global $koneksi;
        $this->koneksi = $koneksi;
    }

    // Method untuk mencatat transaksi (pengurangan stok)
    public function tambahTransaksi($id_produk, $jumlah, $keterangan) {
        // Validasi: jumlah tidak boleh negatif atau 0
        if ($jumlah <= 0) {
            return "ERROR: Jumlah tidak boleh 0 atau negatif!";
        }

        // Cek stok produk terlebih dahulu
        $cek = mysqli_query($this->koneksi, "SELECT stok, nama_produk FROM produk WHERE id = $id_produk");
        $produk = mysqli_fetch_assoc($cek);

        if ($produk['stok'] < $jumlah) {
            return "ERROR: Stok tidak cukup! Stok tersedia: " . $produk['stok'] . " unit.";
        }

        // Kurangi stok di tabel produk
        $updateStok = "UPDATE produk SET stok = stok - $jumlah WHERE id = $id_produk";
        mysqli_query($this->koneksi, $updateStok);

        // Simpan ke tabel transaksi
        $keterangan = mysqli_real_escape_string($this->koneksi, $keterangan);
        $insertTransaksi = "INSERT INTO transaksi (id_produk, jumlah, keterangan) 
                            VALUES ($id_produk, $jumlah, '$keterangan')";
        $hasil = mysqli_query($this->koneksi, $insertTransaksi);

        if ($hasil) {
            return "Transaksi berhasil dicatat!";
        } else {
            return "Gagal mencatat transaksi.";
        }
    }

    // Method untuk mengambil semua riwayat transaksi
    public function getSemuaTransaksi() {
        $query = "SELECT t.id, p.nama_produk, p.tipe, t.jumlah, t.keterangan, t.tanggal 
                  FROM transaksi t 
                  JOIN produk p ON t.id_produk = p.id 
                  ORDER BY t.tanggal DESC";
        $hasil = mysqli_query($this->koneksi, $query);
        return $hasil;
    }

    // Method untuk rekap transaksi per produk
    public function getRekapTransaksi() {
        $query = "SELECT p.nama_produk, p.tipe, p.merek, p.stok,
                         COUNT(t.id) as jumlah_transaksi,
                         SUM(t.jumlah) as total_terjual
                  FROM produk p
                  LEFT JOIN transaksi t ON p.id = t.id_produk
                  GROUP BY p.id
                  ORDER BY total_terjual DESC";
        $hasil = mysqli_query($this->koneksi, $query);
        return $hasil;
    }
}
?>
