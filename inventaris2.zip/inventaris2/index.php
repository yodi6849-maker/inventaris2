<?php
// index.php - Halaman Dashboard
session_start();
require_once "classes/Produk.php";
require_once "classes/Transaksi.php";

$objProduk    = new Produk();
$objTransaksi = new Transaksi();

$semuaProduk   = $objProduk->getSemuaProduk();
$produkMenipis = $objProduk->getProdukMenipis();
$rekapData     = $objTransaksi->getRekapTransaksi();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Inventaris Toko</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #2c3e50;
            padding: 12px 20px;
            color: white;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            font-size: 15px;
        }
        .navbar a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 1100px;
            margin: 20px auto;
            padding: 0 15px;
        }
        h2 {
            color: #2c3e50;
        }
        .card {
            background: white;
            border-radius: 6px;
            padding: 15px 20px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
        }
        .alert-menipis {
            background-color: #fff3cd;
            border: 1px solid #ffc107;
            border-left: 5px solid #ffc107;
            padding: 12px 16px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-menipis h3 {
            color: #856404;
            margin: 0 0 8px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        table th {
            background-color: #2c3e50;
            color: white;
            padding: 10px;
            text-align: left;
        }
        table td {
            padding: 9px 10px;
            border-bottom: 1px solid #eee;
        }
        table tr:hover {
            background-color: #f9f9f9;
        }
        .badge-menipis {
            background-color: #e74c3c;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .badge-aman {
            background-color: #27ae60;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .pesan-sukses {
            background: #d4edda;
            border: 1px solid #28a745;
            color: #155724;
            padding: 10px 14px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .pesan-error {
            background: #f8d7da;
            border: 1px solid #dc3545;
            color: #721c24;
            padding: 10px 14px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<!-- Navbar navigasi -->
<div class="navbar">
    <strong>🏪 Inventaris Toko Retail</strong> &nbsp;|&nbsp;
    <a href="index.php">Dashboard</a>
    <a href="produk.php">Kelola Produk</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="rekap.php">Rekap</a>
</div>

<div class="container">

    <h2>📊 Dashboard</h2>

    <?php
    // Tampilkan pesan jika ada
    if (isset($_SESSION['pesan'])) {
        $tipe_pesan = $_SESSION['tipe_pesan'];
        $kelas = ($tipe_pesan == 'sukses') ? 'pesan-sukses' : 'pesan-error';
        echo "<div class='$kelas'>" . $_SESSION['pesan'] . "</div>";
        unset($_SESSION['pesan']);
        unset($_SESSION['tipe_pesan']);
    }
    ?>

    <!-- Peringatan Stok Menipis (otomatis jika stok < 5) -->
    <?php
    $jumlah_menipis = mysqli_num_rows($produkMenipis);
    if ($jumlah_menipis > 0) {
        // Reset pointer karena nanti dipakai lagi
        mysqli_data_seek($produkMenipis, 0);
    ?>
    <div class="alert-menipis">
        <h3>⚠️ Peringatan: Stok Menipis!</h3>
        <p>Produk berikut memiliki stok di bawah 5 unit, segera lakukan restok:</p>
        <ul>
        <?php
        while ($row = mysqli_fetch_assoc($produkMenipis)) {
            echo "<li><b>" . $row['nama_produk'] . "</b> - Sisa stok: <b>" . $row['stok'] . " unit</b></li>";
        }
        ?>
        </ul>
    </div>
    <?php } ?>

    <!-- Tabel data stok semua produk -->
    <div class="card">
        <h3>📦 Data Stok Produk</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Merek</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status Stok</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            while ($produk = mysqli_fetch_assoc($semuaProduk)) {
                // Cek apakah stok menipis
                $statusStok = "";
                if ($objProduk->cekStokMenipis($produk['stok'])) {
                    $statusStok = "<span class='badge-menipis'>⚠️ Stok Menipis</span>";
                } else {
                    $statusStok = "<span class='badge-aman'>✅ Aman</span>";
                }

                echo "<tr>
                    <td>$no</td>
                    <td>" . $produk['nama_produk'] . "</td>
                    <td>" . $produk['tipe'] . "</td>
                    <td>" . $produk['merek'] . "</td>
                    <td>Rp " . number_format($produk['harga'], 0, ',', '.') . "</td>
                    <td><b>" . $produk['stok'] . " unit</b></td>
                    <td>$statusStok</td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

    <!-- Rekap transaksi -->
    <div class="card">
        <h3>📋 Rekap Transaksi Per Produk</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Jumlah Transaksi</th>
                    <th>Total Terjual</th>
                    <th>Sisa Stok</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            while ($rekap = mysqli_fetch_assoc($rekapData)) {
                $total = $rekap['total_terjual'] ?? 0;
                $jml   = $rekap['jumlah_transaksi'] ?? 0;
                echo "<tr>
                    <td>$no</td>
                    <td>" . $rekap['nama_produk'] . "</td>
                    <td>" . $rekap['tipe'] . "</td>
                    <td>$jml kali</td>
                    <td>$total unit</td>
                    <td>" . $rekap['stok'] . " unit</td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

</div><!-- end container -->

</body>
</html>
