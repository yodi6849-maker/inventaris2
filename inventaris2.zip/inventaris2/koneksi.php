<?php
// koneksi.php
// File ini digunakan untuk menghubungkan ke database MySQL

$host     = "localhost";
$user     = "root";
$password = "";
$database = "db_inventaris";

$koneksi = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
