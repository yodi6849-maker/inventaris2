<?php
// produk.php - Halaman untuk mengelola produk (tambah, edit, hapus)
session_start();
require_once "classes/Produk.php";

$objProduk = new Produk();

// =============================
// Proses Tambah Produk
// =============================
if (isset($_POST['tambah'])) {
    $nama  = $_POST['nama_produk'];
    $tipe  = $_POST['tipe'];
    $merek = $_POST['merek'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    // Validasi stok negatif
    if ($stok < 0) {
        $_SESSION['pesan']      = "❌ Stok tidak boleh bernilai negatif/minus!";
        $_SESSION['tipe_pesan'] = "error";
    } else {
        $hasil = $objProduk->tambah($nama, $tipe, $merek, $harga, $stok);

        if (strpos($hasil, "ERROR") !== false) {
            $_SESSION['pesan']      = "❌ " . $hasil;
            $_SESSION['tipe_pesan'] = "error";
        } else {
            $_SESSION['pesan']      = "✅ " . $hasil;
            $_SESSION['tipe_pesan'] = "sukses";
        }
    }

    header("Location: produk.php");
    exit;
}

// =============================
// Proses Edit Produk
// =============================
if (isset($_POST['edit'])) {
    $id    = $_POST['id'];
    $nama  = $_POST['nama_produk'];
    $tipe  = $_POST['tipe'];
    $merek = $_POST['merek'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    // Validasi stok negatif
    if ($stok < 0) {
        $_SESSION['pesan']      = "❌ Stok tidak boleh bernilai negatif/minus!";
        $_SESSION['tipe_pesan'] = "error";
    } else {
        $hasil = $objProduk->edit($id, $nama, $tipe, $merek, $harga, $stok);
        $_SESSION['pesan']      = "✅ " . $hasil;
        $_SESSION['tipe_pesan'] = "sukses";
    }

    header("Location: produk.php");
    exit;
}

// =============================
// Proses Hapus Produk
// =============================
if (isset($_GET['hapus'])) {
    $id    = $_GET['hapus'];
    $hasil = $objProduk->hapus($id);
    $_SESSION['pesan']      = "✅ " . $hasil;
    $_SESSION['tipe_pesan'] = "sukses";
    header("Location: produk.php");
    exit;
}

// Ambil data produk untuk form edit (jika ada)
$dataEdit = null;
if (isset($_GET['edit'])) {
    $dataEdit = $objProduk->getProdukById($_GET['edit']);
}

$semuaProduk = $objProduk->getSemuaProduk();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Produk - Inventaris Toko</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #2c3e50; padding: 12px 20px; color: white; }
        .navbar a { color: white; text-decoration: none; margin-right: 20px; font-size: 15px; }
        .navbar a:hover { text-decoration: underline; }
        .container { max-width: 1100px; margin: 20px auto; padding: 0 15px; }
        h2, h3 { color: #2c3e50; }
        .card { background: white; border-radius: 6px; padding: 15px 20px; margin-bottom: 20px; border: 1px solid #ddd; }
        label { display: block; margin-top: 10px; font-weight: bold; font-size: 14px; }
        input[type="text"], input[type="number"], select {
            width: 100%; padding: 8px; margin-top: 4px;
            border: 1px solid #ccc; border-radius: 4px;
            box-sizing: border-box; font-size: 14px;
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        button {
            margin-top: 14px; padding: 9px 20px;
            border: none; border-radius: 4px;
            color: white; cursor: pointer; font-size: 14px;
        }
        .btn-hijau  { background-color: #27ae60; }
        .btn-biru   { background-color: #2980b9; }
        .btn-merah  { background-color: #e74c3c; }
        .btn-kuning { background-color: #f39c12; }
        button:hover { opacity: 0.9; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        table th { background-color: #2c3e50; color: white; padding: 10px; text-align: left; }
        table td { padding: 9px 10px; border-bottom: 1px solid #eee; }
        table tr:hover { background-color: #f9f9f9; }
        .badge-menipis { background-color: #e74c3c; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .badge-aman    { background-color: #27ae60; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .pesan-sukses  { background: #d4edda; border: 1px solid #28a745; color: #155724; padding: 10px 14px; margin-bottom: 15px; border-radius: 4px; }
        .pesan-error   { background: #f8d7da; border: 1px solid #dc3545; color: #721c24; padding: 10px 14px; margin-bottom: 15px; border-radius: 4px; }
        small { color: #888; font-size: 12px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>🏪 Inventaris Toko Retail</strong> &nbsp;|&nbsp;
    <a href="index.php">Dashboard</a>
    <a href="produk.php">Kelola Produk</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="rekap.php">Rekap</a>
</div>

<div class="container">

    <h2>📦 Kelola Produk</h2>

    <?php
    if (isset($_SESSION['pesan'])) {
        $kelas = ($_SESSION['tipe_pesan'] == 'sukses') ? 'pesan-sukses' : 'pesan-error';
        echo "<div class='$kelas'>" . $_SESSION['pesan'] . "</div>";
        unset($_SESSION['pesan']);
        unset($_SESSION['tipe_pesan']);
    }
    ?>

    <!-- Form Tambah / Edit Produk -->
    <div class="card">
        <?php if ($dataEdit): ?>
            <h3>✏️ Edit Produk</h3>
        <?php else: ?>
            <h3>➕ Tambah Produk Baru</h3>
        <?php endif; ?>

        <form method="POST" action="produk.php"
              onsubmit="return validasiForm()">

            <?php if ($dataEdit): ?>
                <!-- Kalau edit, kirim id produknya -->
                <input type="hidden" name="id" value="<?= $dataEdit['id'] ?>">
            <?php endif; ?>

            <div class="form-row">
                <div>
                    <label>Nama Produk</label>
                    <input type="text" name="nama_produk" required
                           value="<?= $dataEdit ? $dataEdit['nama_produk'] : '' ?>"
                           placeholder="Contoh: MacBook Air M2">
                </div>
                <div>
                    <label>Merek</label>
                    <input type="text" name="merek" required
                           value="<?= $dataEdit ? $dataEdit['merek'] : '' ?>"
                           placeholder="Contoh: Apple">
                </div>
            </div>

            <div class="form-row">
                <div>
                    <label>Tipe Produk</label>
                    <select name="tipe" required>
                        <option value="">-- Pilih Tipe --</option>
                        <option value="Laptop"
                            <?= ($dataEdit && $dataEdit['tipe'] == 'Laptop') ? 'selected' : '' ?>>
                            Laptop
                        </option>
                        <option value="Smartphone"
                            <?= ($dataEdit && $dataEdit['tipe'] == 'Smartphone') ? 'selected' : '' ?>>
                            Smartphone
                        </option>
                    </select>
                </div>
                <div>
                    <label>Harga (Rp)</label>
                    <input type="number" name="harga" required min="0"
                           value="<?= $dataEdit ? $dataEdit['harga'] : '' ?>"
                           placeholder="Contoh: 15000000">
                </div>
            </div>

            <div style="max-width: 200px">
                <label>Jumlah Stok</label>
                <input type="number" name="stok" id="stok" required min="0"
                       value="<?= $dataEdit ? $dataEdit['stok'] : '' ?>"
                       placeholder="Contoh: 10">
                <small>*Stok tidak boleh bernilai negatif</small>
            </div>

            <br>
            <?php if ($dataEdit): ?>
                <button type="submit" name="edit" class="btn-kuning">💾 Simpan Perubahan</button>
                <a href="produk.php">
                    <button type="button" class="btn-merah">✕ Batal</button>
                </a>
            <?php else: ?>
                <button type="submit" name="tambah" class="btn-hijau">➕ Tambah Produk</button>
            <?php endif; ?>

        </form>
    </div>

    <!-- Tabel Daftar Produk -->
    <div class="card">
        <h3>📋 Daftar Semua Produk</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Merek</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            while ($produk = mysqli_fetch_assoc($semuaProduk)) {
                $status = "";
                if ($objProduk->cekStokMenipis($produk['stok'])) {
                    $status = "<span class='badge-menipis'>⚠️ Stok Menipis</span>";
                } else {
                    $status = "<span class='badge-aman'>✅ Aman</span>";
                }

                echo "<tr>
                    <td>$no</td>
                    <td>" . $produk['nama_produk'] . "</td>
                    <td>" . $produk['tipe'] . "</td>
                    <td>" . $produk['merek'] . "</td>
                    <td>Rp " . number_format($produk['harga'], 0, ',', '.') . "</td>
                    <td>" . $produk['stok'] . " unit</td>
                    <td>$status</td>
                    <td>
                        <a href='produk.php?edit=" . $produk['id'] . "'>
                            <button class='btn-biru' style='padding:5px 12px; margin-top:0'>✏️ Edit</button>
                        </a>
                        <a href='produk.php?hapus=" . $produk['id'] . "' 
                           onclick=\"return confirm('Yakin mau hapus produk ini?')\">
                            <button class='btn-merah' style='padding:5px 12px; margin-top:0'>🗑️ Hapus</button>
                        </a>
                    </td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

</div>

<script>
// Validasi form sebelum submit
function validasiForm() {
    var stok = document.getElementById('stok').value;
    if (stok < 0) {
        alert("❌ Stok tidak boleh bernilai negatif/minus!");
        return false;
    }
    return true;
}
</script>

</body>
</html>
