<?php
// rekap.php - Halaman Rekap Transaksi
session_start();
require_once "classes/Produk.php";
require_once "classes/Transaksi.php";

$objProduk    = new Produk();
$objTransaksi = new Transaksi();

$rekapData      = $objTransaksi->getRekapTransaksi();
$semuaTransaksi = $objTransaksi->getSemuaTransaksi();
$produkMenipis  = $objProduk->getProdukMenipis();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rekap Transaksi - Inventaris Toko</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #2c3e50; padding: 12px 20px; color: white; }
        .navbar a { color: white; text-decoration: none; margin-right: 20px; font-size: 15px; }
        .navbar a:hover { text-decoration: underline; }
        .container { max-width: 1100px; margin: 20px auto; padding: 0 15px; }
        h2, h3 { color: #2c3e50; }
        .card { background: white; border-radius: 6px; padding: 15px 20px; margin-bottom: 20px; border: 1px solid #ddd; }
        .alert-menipis { background-color: #fff3cd; border: 1px solid #ffc107; border-left: 5px solid #ffc107; padding: 12px 16px; margin-bottom: 20px; border-radius: 4px; }
        .alert-menipis h3 { color: #856404; margin: 0 0 8px 0; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        table th { background-color: #2c3e50; color: white; padding: 10px; text-align: left; }
        table td { padding: 9px 10px; border-bottom: 1px solid #eee; }
        table tr:hover { background-color: #f9f9f9; }
        .badge-menipis { background-color: #e74c3c; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .badge-aman { background-color: #27ae60; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>🏪 Inventaris Toko Retail</strong> &nbsp;|&nbsp;
    <a href="index.php">Dashboard</a>
    <a href="produk.php">Kelola Produk</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="rekap.php">Rekap</a>
</div>

<div class="container">

    <h2>📋 Rekap Transaksi</h2>

    <!-- Peringatan stok menipis -->
    <?php if (mysqli_num_rows($produkMenipis) > 0): ?>
    <div class="alert-menipis">
        <h3>⚠️ Peringatan: Stok Menipis!</h3>
        <ul>
        <?php while ($p = mysqli_fetch_assoc($produkMenipis)): ?>
            <li><b><?= $p['nama_produk'] ?></b> — Sisa: <b><?= $p['stok'] ?> unit</b></li>
        <?php endwhile; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Rekap per produk -->
    <div class="card">
        <h3>📊 Rekap Per Produk</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Merek</th>
                    <th>Jml Transaksi</th>
                    <th>Total Terjual</th>
                    <th>Sisa Stok</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            while ($r = mysqli_fetch_assoc($rekapData)) {
                $total = $r['total_terjual'] ?? 0;
                $jml   = $r['jumlah_transaksi'] ?? 0;

                $status = "";
                if ($objProduk->cekStokMenipis($r['stok'])) {
                    $status = "<span class='badge-menipis'>⚠️ Stok Menipis</span>";
                } else {
                    $status = "<span class='badge-aman'>✅ Aman</span>";
                }

                echo "<tr>
                    <td>$no</td>
                    <td>" . $r['nama_produk'] . "</td>
                    <td>" . $r['tipe'] . "</td>
                    <td>" . $r['merek'] . "</td>
                    <td>$jml kali</td>
                    <td>$total unit</td>
                    <td>" . $r['stok'] . " unit</td>
                    <td>$status</td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

    <!-- Semua riwayat transaksi -->
    <div class="card">
        <h3>📜 Semua Riwayat Transaksi</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Jumlah</th>
                    <th>Keterangan</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            if (mysqli_num_rows($semuaTransaksi) == 0) {
                echo "<tr><td colspan='6' style='text-align:center; color:#aaa; padding:20px;'>Belum ada transaksi.</td></tr>";
            }
            while ($t = mysqli_fetch_assoc($semuaTransaksi)) {
                $tanggal = date('d/m/Y H:i', strtotime($t['tanggal']));
                echo "<tr>
                    <td>$no</td>
                    <td>" . $t['nama_produk'] . "</td>
                    <td>" . $t['tipe'] . "</td>
                    <td style='color:red; font-weight:bold;'>-" . $t['jumlah'] . " unit</td>
                    <td>" . ($t['keterangan'] ? $t['keterangan'] : '-') . "</td>
                    <td>$tanggal</td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
