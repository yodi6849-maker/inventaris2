<?php
// transaksi.php - Halaman untuk mencatat transaksi (pengurangan stok)
session_start();
require_once "classes/Produk.php";
require_once "classes/Transaksi.php";

$objProduk    = new Produk();
$objTransaksi = new Transaksi();

// =============================
// Proses Form Transaksi
// =============================
if (isset($_POST['catat'])) {
    $id_produk  = $_POST['id_produk'];
    $jumlah     = $_POST['jumlah'];
    $keterangan = $_POST['keterangan'];

    // Validasi: jumlah tidak boleh negatif atau 0
    if ($jumlah <= 0) {
        $_SESSION['pesan']      = "❌ Jumlah tidak boleh 0 atau negatif!";
        $_SESSION['tipe_pesan'] = "error";
    } else {
        $hasil = $objTransaksi->tambahTransaksi($id_produk, $jumlah, $keterangan);

        if (strpos($hasil, "ERROR") !== false) {
            $_SESSION['pesan']      = "❌ " . $hasil;
            $_SESSION['tipe_pesan'] = "error";
        } else {
            $_SESSION['pesan']      = "✅ " . $hasil;
            $_SESSION['tipe_pesan'] = "sukses";
        }
    }

    header("Location: transaksi.php");
    exit;
}

$semuaProduk    = $objProduk->getSemuaProduk();
$semuaTransaksi = $objTransaksi->getSemuaTransaksi();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi - Inventaris Toko</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #2c3e50; padding: 12px 20px; color: white; }
        .navbar a { color: white; text-decoration: none; margin-right: 20px; font-size: 15px; }
        .navbar a:hover { text-decoration: underline; }
        .container { max-width: 1100px; margin: 20px auto; padding: 0 15px; }
        h2, h3 { color: #2c3e50; }
        .card { background: white; border-radius: 6px; padding: 15px 20px; margin-bottom: 20px; border: 1px solid #ddd; }
        label { display: block; margin-top: 10px; font-weight: bold; font-size: 14px; }
        input[type="text"], input[type="number"], select {
            width: 100%; padding: 8px; margin-top: 4px;
            border: 1px solid #ccc; border-radius: 4px;
            box-sizing: border-box; font-size: 14px;
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        button { margin-top: 14px; padding: 9px 20px; border: none; border-radius: 4px; color: white; cursor: pointer; font-size: 14px; }
        .btn-merah  { background-color: #e74c3c; }
        button:hover { opacity: 0.9; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        table th { background-color: #2c3e50; color: white; padding: 10px; text-align: left; }
        table td { padding: 9px 10px; border-bottom: 1px solid #eee; }
        table tr:hover { background-color: #f9f9f9; }
        .pesan-sukses { background: #d4edda; border: 1px solid #28a745; color: #155724; padding: 10px 14px; margin-bottom: 15px; border-radius: 4px; }
        .pesan-error  { background: #f8d7da; border: 1px solid #dc3545; color: #721c24; padding: 10px 14px; margin-bottom: 15px; border-radius: 4px; }
        #infoStok { background: #e8f4fd; border: 1px solid #3498db; padding: 8px 12px; border-radius: 4px; margin-top: 8px; font-size: 13px; display: none; }
        small { color: #888; font-size: 12px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>🏪 Inventaris Toko Retail</strong> &nbsp;|&nbsp;
    <a href="index.php">Dashboard</a>
    <a href="produk.php">Kelola Produk</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="rekap.php">Rekap</a>
</div>

<div class="container">

    <h2>🔄 Catat Transaksi</h2>

    <?php
    if (isset($_SESSION['pesan'])) {
        $kelas = ($_SESSION['tipe_pesan'] == 'sukses') ? 'pesan-sukses' : 'pesan-error';
        echo "<div class='$kelas'>" . $_SESSION['pesan'] . "</div>";
        unset($_SESSION['pesan']);
        unset($_SESSION['tipe_pesan']);
    }
    ?>

    <!-- Form Catat Transaksi -->
    <div class="card">
        <h3>➖ Catat Pengurangan Stok</h3>

        <form method="POST" action="transaksi.php" onsubmit="return validasiTransaksi()">

            <label>Pilih Produk</label>
            <select name="id_produk" id="pilihProduk" required onchange="tampilkanStok(this)">
                <option value="">-- Pilih Produk --</option>
                <?php
                while ($p = mysqli_fetch_assoc($semuaProduk)) {
                    echo "<option value='" . $p['id'] . "' data-stok='" . $p['stok'] . "'>"
                        . $p['nama_produk'] . " (" . $p['merek'] . ") - Stok: " . $p['stok'] . " unit"
                        . "</option>";
                }
                ?>
            </select>

            <!-- Info stok tersedia (muncul setelah pilih produk) -->
            <div id="infoStok">
                Stok tersedia: <strong id="nilaiStok"></strong> unit
            </div>

            <div class="form-row" style="margin-top: 10px">
                <div>
                    <label>Jumlah Dikurangi</label>
                    <input type="number" name="jumlah" id="jumlah" min="1" required
                           placeholder="Contoh: 2">
                    <small>*Jumlah tidak boleh 0 atau negatif</small>
                </div>
                <div>
                    <label>Keterangan</label>
                    <input type="text" name="keterangan"
                           placeholder="Contoh: Penjualan ke customer">
                </div>
            </div>

            <button type="submit" name="catat" class="btn-merah">➖ Catat Transaksi</button>

        </form>
    </div>

    <!-- Riwayat Transaksi -->
    <div class="card">
        <h3>📜 Riwayat Transaksi</h3>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Tipe</th>
                    <th>Jumlah Dikurangi</th>
                    <th>Keterangan</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            $jumlahData = mysqli_num_rows($semuaTransaksi);
            if ($jumlahData == 0) {
                echo "<tr><td colspan='6' style='text-align:center; color:#aaa; padding:20px;'>Belum ada transaksi.</td></tr>";
            }
            while ($t = mysqli_fetch_assoc($semuaTransaksi)) {
                $tanggal = date('d/m/Y H:i', strtotime($t['tanggal']));
                echo "<tr>
                    <td>$no</td>
                    <td>" . $t['nama_produk'] . "</td>
                    <td>" . $t['tipe'] . "</td>
                    <td style='color:red; font-weight:bold;'>-" . $t['jumlah'] . " unit</td>
                    <td>" . ($t['keterangan'] ? $t['keterangan'] : '-') . "</td>
                    <td>$tanggal</td>
                </tr>";
                $no++;
            }
            ?>
            </tbody>
        </table>
    </div>

</div>

<script>
// Tampilkan info stok saat produk dipilih
function tampilkanStok(select) {
    var stok   = select.options[select.selectedIndex].getAttribute('data-stok');
    var infoEl = document.getElementById('infoStok');
    var nilaiEl = document.getElementById('nilaiStok');

    if (select.value != '') {
        infoEl.style.display = 'block';
        nilaiEl.textContent  = stok;
    } else {
        infoEl.style.display = 'none';
    }
}

// Validasi sebelum submit
function validasiTransaksi() {
    var jumlah = document.getElementById('jumlah').value;
    if (jumlah <= 0) {
        alert("❌ Jumlah tidak boleh 0 atau negatif!");
        return false;
    }
    return true;
}
</script>

</body>
</html>
